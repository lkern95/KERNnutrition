import { CheckinPage } from './pages/CheckinPage.tsx'

console.log('CheckinPage imported successfully:', CheckinPage)
